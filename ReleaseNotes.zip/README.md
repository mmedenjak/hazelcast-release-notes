
Required packages:

- Node.js: http://nodejs.org
- Bfdocs: http://beautifuldocs.com
- Pandoc: http://johnmacfarlane.net/pandoc/installing.html
- BasicTeX: http://www.tug.org/mactex/morepackages.html

Installation with Ubuntu:

`sudo apt-get install nodejs nodejs-legacy npm pandoc texlive`

NOTE: [Beautiful Docs](https://github.com/beautiful-docs/beautiful-docs) repo should be cloned and compiled from source since the latest release does not include recent fixes which is vital for us!
