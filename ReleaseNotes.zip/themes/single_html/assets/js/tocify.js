$function() {
$("#toc").tocify();
}